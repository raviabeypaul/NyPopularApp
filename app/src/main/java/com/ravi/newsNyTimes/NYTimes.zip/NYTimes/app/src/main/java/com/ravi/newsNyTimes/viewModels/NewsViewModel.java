package com.ravi.newsNyTimes.viewModels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.ravi.newsNyTimes.Repositories.NewsRepository;
import com.ravi.newsNyTimes.model.ApiResponse;
import com.ravi.newsNyTimes.utility.Constant;


public class NewsViewModel extends AndroidViewModel {

    String sections = "all-sections";
    String period = "1";
    private MutableLiveData<ApiResponse> mutableLiveData;
    private NewsRepository newsRepository;

    public NewsViewModel(@NonNull Application application) {
        super(application);
    }


    public void init(){
        if (mutableLiveData != null){
            return;
        }
        newsRepository = NewsRepository.getInstance();
        mutableLiveData = newsRepository.getNews(sections, period, Constant.API_KEY);

    }

    public LiveData<ApiResponse> getNewsRepository() {
        return mutableLiveData;
    }

}
