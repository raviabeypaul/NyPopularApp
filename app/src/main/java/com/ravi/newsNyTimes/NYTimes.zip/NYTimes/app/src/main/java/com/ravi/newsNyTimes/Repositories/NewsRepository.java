package com.ravi.newsNyTimes.Repositories;


import androidx.lifecycle.MutableLiveData;

import com.ravi.newsNyTimes.model.ApiResponse;
import com.ravi.newsNyTimes.networking.NewsApi;
import com.ravi.newsNyTimes.networking.RetrofitService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewsRepository {

    private static NewsRepository newsRepository;

    public static NewsRepository getInstance(){
        if (newsRepository == null){
            newsRepository = new NewsRepository();
        }
        return newsRepository;
    }

    private NewsApi newsApi;

    public NewsRepository(){
        newsApi = RetrofitService.cteateService(NewsApi.class);
    }

    public MutableLiveData<ApiResponse> getNews(String section, String period,
                                                String apiKey){

        final MutableLiveData<ApiResponse> newsData = new MutableLiveData<>();
        newsApi.getNewsDetails(section, period, apiKey).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call,
                                   Response<ApiResponse> response) {
                if (response.isSuccessful()){
                    newsData.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                newsData.setValue(null);
            }
        });
        return newsData;
    }
}
